# Sitemap-for-Typecho
a Sitemap Plugin for Typecho

把Sitemap文件夹上传至插件目录,然后启用，访问http://your_site/sitemap.xml就可以了
